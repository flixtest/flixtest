({
    
    fetchClauses : function(component, event, helper) {
		var recordId = component.get('v.recordId');
        var action = component.get("c.fetchClausesBack");
        action.setParams({
            acctId: recordId
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                if(response.getReturnValue().length == 0){
                    component.set("v.zeroRecords", true);
                }else{
              		component.set("v.clauseList", response.getReturnValue());      
                }                
            }
        });
        $A.enqueueAction(action);        	
    },
    
    
    handleProceed : function(component, event, helper) {
    	// get the list of Clause records
    	console.log('inside handleproceed');
        var clauseRecs = component.get('v.clauseList');
        console.log('clauseRecs'+JSON.stringify(clauseRecs));
        // map through the list to create a list of Clauseids
        var clauseIds = clauseRecs.map(function (clauseRec) {
            return clauseRec.Id;
        });
        console.log('clauseIds'+clauseIds);
        var recordId = component.get('v.recordId');
        var saveAction = component.get("c.saveAccountContract");        
        console.log('before action call');
        saveAction.setParams({
            acctId: recordId,
            "clauseIds": clauseIds
        });
        
        saveAction.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
            	//success toast 
            	var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title : 'Success',
                    message: 'Account Contract created successfully',
                    duration:'2000',
                    key: 'info_alt',
                    type: 'success',
                    mode: 'pester'
                });
                toastEvent.fire();
                var contractPanel = $A.get("e.force:closeQuickAction");
        		contractPanel.fire();
            }else{
                //error toast  
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title : 'Error',
                    message:'Error occurred while saving the record.Try again or reach out to Admin for further support',
                    duration:'3000',
                    key: 'info_alt',
                    type: 'error',
                    mode: 'pester'
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(saveAction);
    },
    
    // function automatic called by aura:waiting event  
    showSpinner: function(component, event, helper) {
        // make Spinner attribute true for displaying loading spinner 
        component.set("v.spinner", true); 
    },
     
    // function automatic called by aura:doneWaiting event 
    hideSpinner : function(component,event,helper){
        // make Spinner attribute to false for hiding loading spinner    
        component.set("v.spinner", false);
    }
    
    
})